import unittest
from src.Lottery import Lottery


class TestLottery(unittest.TestCase):

    def test_brak_powtorzen(self):
        lotto = Lottery([1, 2, 3, 4, 5], 2)
        self.assertEqual(lotto.find(), [])

    def test_jeden_powtarzajacy_sie_podzbior(self):
        lotto = Lottery([7, 7, 7, 7, 8, 7, 7, 7], 3)
        self.assertEqual(lotto.find(), [(7, 7, 7)])

    def test_rozmiar_wiekszy_niz_lista(self):
        lotto = Lottery([1, 2], 5)
        self.assertEqual(lotto.find(), [])

    def test_rozmiar_zero(self):
        lotto = Lottery([1, 2, 3], 0)
        self.assertEqual(lotto.find(), [])

    def test_wiele_powtorzen_tego_samego(self):
        lotto = Lottery([5, 5, 5, 5, 5], 2)
        self.assertEqual(lotto.find(), [(5, 5)])

    def test_brak_jednolitych_podzbiorow(self):
        lotto = Lottery([1, 2, 3, 4, 5, 6], 3)
        self.assertEqual(lotto.find(), [])

    def test_jednolity_ale_nie_powtarzajacy_sie(self):
        lotto = Lottery([9, 9, 9], 3)
        self.assertEqual(lotto.find(), [])


if __name__ == '__main__':
    unittest.main()
