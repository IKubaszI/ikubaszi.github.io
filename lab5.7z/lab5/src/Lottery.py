class Lottery:
    def __init__(self, lista, rozmiar):
        self.lista = lista
        self.rozmiar = rozmiar

    def find(self):
        if self.rozmiar <= 0 or self.rozmiar > len(self.lista):
            return []

        podzbiory = []

        for i in range(len(self.lista) - self.rozmiar + 1):
            podzbior = tuple(self.lista[i:i + self.rozmiar])
            if all(x == podzbior[0] for x in podzbior):
                podzbiory.append(podzbior)

        wynik = []
        for i in range(len(podzbiory)):
            ile = 1
            for j in range(i + 1, len(podzbiory)):
                if podzbiory[i] == podzbiory[j]:
                    ile += 1
            if ile > 1 and podzbiory[i] not in wynik:
                wynik.append(podzbiory[i])

        return sorted(wynik)


lista = [7, 7, 8, 9]
rozmiar = 3

lotto = Lottery(lista, rozmiar)
print(lotto.find())