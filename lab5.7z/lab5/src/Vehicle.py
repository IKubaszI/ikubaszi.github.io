class Vehicle:
    def __init__(self):
        self.grid_size = 10

        self.x = 0
        self.y = 0

        self.angle = 0

    def rotate_left(self):
        self.angle = (self.angle + 90) % 360

    def rotate_right(self):
        self.angle = (self.angle - 90) % 360

    def move_forward(self, steps=1):
        if self.angle == 0:
            self.x += steps
        elif self.angle == 90:
            self.y += steps
        elif self.angle == 180:
            self.x -= steps
        elif self.angle == 270:
            self.y -= steps

        self.x = max(0, min(self.x, self.grid_size - 1))
        self.y = max(0, min(self.y, self.grid_size - 1))

    def get_position(self):
        return self.x, self.y
